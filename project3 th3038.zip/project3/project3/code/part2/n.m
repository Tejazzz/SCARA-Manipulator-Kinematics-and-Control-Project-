function output=n(input)
