function [output]=jacobian_dot(input)
