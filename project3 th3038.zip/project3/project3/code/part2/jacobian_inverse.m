function [output]=jacobian_inverse(input)
